Assignment 5:
Run locally:
    npm install
    npm run
    (install nodemon if needed)
Run on github
    Build AMI from ami.pkr.hcl file, copy ami_id to cloudformation and run cloudformation
    run application on postman
