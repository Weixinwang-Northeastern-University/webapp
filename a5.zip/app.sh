#!/bin/sh
cd /home/ubuntu/a5
sudo npm start | tee ./app.log
